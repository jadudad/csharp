﻿using static System.Console;

// 90 page

class Car 
{
    private int speed = 0;

    public Car() { }    
}
class Program
{
    public static void Main()
    {
        Car c1 = new Car();
        Car c2 = new Car();


    }
}
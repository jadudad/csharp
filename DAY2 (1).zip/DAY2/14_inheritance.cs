﻿class Professor 
{
    private string name;
    private string major;
}
class Student 
{
    private string name;
    private string id;
} 

class Program
{
    public static void Main()
    {

    }
}
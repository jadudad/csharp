﻿using static System.Console;

class Bike
{
    public int gear = 0;
}


class Program
{
    public static void Main()
    {
        Bike b = new Bike();

        b.gear = 5;
    }
}



﻿// named argument - 74 page

class Program
{
    public static void SetRect(int x,     int y, 
							   int width, int height) {}

    public static void Main()
    {
		// positional arguments
        SetRect(10, 10, 30, 30);
				
 						
    }
}

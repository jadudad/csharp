using static System.Console;

// 79 page
class Program
{
	public static void Inc(int x)
	{
		++x;
	}

	public static void Main()
	{
		int n = 0;
		Inc(n);

		WriteLine(n); // 0 ? 1
	}
}
﻿using static System.Console;

// static constructor - 92 page
class Train
{
    public Train() { WriteLine("Train()"); }
}

class Program
{
    public static void Main()
    {
        Train t1 = new Train();                                 
        Train t2 = new Train(); 
        Train t3 = new Train(); 
    }
}
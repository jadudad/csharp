﻿using System;

// in(C#7.2), ref readonly(C#12.0)

class Program
{
    public static void M1(int n)
    {
        int a = n;  
    }

    public static void M2(int n)
    {
        int a = n;  
    }

    public static void Main()
    {
        int x = 0;
        M1(x);
        M2(x);
    }
}
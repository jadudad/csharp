using static System.Console;

class Person
{
	private int age;

	public int Age 
	{
		get => age;
		set => age = value;		
	}

	private string firstName = null!;
	private string lastName = null!;

	public required string FirstName 
	{
		get => firstName;
		set => firstName = value;
	}
	public required string LastName 
	{
		get => lastName;
		set => lastName = value;
	}
}
class Program 
{
	public static void Main()
	{
		Person p = new Person{FirstName = "Susan",
							  LastName = "Connor",
							  Age = 20};

//		WriteLine($"{p.FullName}, {p.IsAdult}");
	}
}

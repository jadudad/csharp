using static System.Console;

// optional Parameter - 76
class Program
{
    public static void M1(int a, int b, int c)
	{
	 	WriteLine($"{a}, {b}, {c}");
	} 
    public static void Main()
    {
        M1(10, 20, 30); //
        M1(10, 20);	 	//
        M1(10);         //
    }

}
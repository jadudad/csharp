﻿// expression bodied - 71 page
class Program
{
    public static int Square1(int x)
    {
        return x * x;
    }
    public static void Main()
    {
        int n = Square1(3);
    }
}
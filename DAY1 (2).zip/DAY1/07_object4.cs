using static System.Console;

string s = "abcd";

bool b = s.Contains('b');
int  n = s.Length;       

WriteLine($"{b} {n}");


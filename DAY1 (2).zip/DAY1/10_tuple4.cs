using static System.Console;

string Get1()       // 반환값이 한개 입니다 
{
    return "john";
}

(string, int) Get2() // 튜플을 사용해서 2개 반환 합니다. 
{
    return ("john", 30);
}

(string name, int age) Get3() // Named Member 를 사용합니다. 
{
    return ("john", 30);
}

var ret1 = Get1();  // ret1 은 string 
var ret2 = Get2();
var ret3 = Get3();
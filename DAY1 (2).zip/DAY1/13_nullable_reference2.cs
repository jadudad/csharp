//#nullable enable
string s1 = null;
string? s2 = null;



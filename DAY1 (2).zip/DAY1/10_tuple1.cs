﻿// tuple - 46 page

int[] arr = { 1, 2, 3 };

var tp = (1, 3.4, 'A');

using static System.Console;

// null conditional operator ( ?, ?[]) - 62 page

string s1 = "hello";
string s2 = null;

var ret1 = s1.ToString(); 
var ret2 = s2.ToString();


// 
int[] arr = null;
int n = arr[0]; // ?
using System;
using static System.Console;


int n1 = new int();
int n2 = 0;

string s1 = new string("ABCD")
string s2 = "ABCD";

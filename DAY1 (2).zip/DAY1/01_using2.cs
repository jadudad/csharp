using static System.Console;

Write("Hello, ");
WriteLine("C#");
// input. 15 page
using System;

Console.Write("input your name >> ");

string s = Console.ReadLine();	 

Console.WriteLine(s);	   		
 
      
  
  
   
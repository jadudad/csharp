using static System.Console;

// 58 page

int  n = 0;

// int? <= int
int? n1 = n;

// int <= int?
int n2 = n1; // 

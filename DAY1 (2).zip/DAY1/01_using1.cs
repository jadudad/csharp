// 10 page
using System;

Console.Write("Hello, ");
Console.WriteLine("C#");


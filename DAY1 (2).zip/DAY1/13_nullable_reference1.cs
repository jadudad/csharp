string s = null;

s.ToString();

int  n1 = 10;
int? n2 = null;

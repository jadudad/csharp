// CTS - 29 page
using System;

int   n1 = 0;
Int32 n2 = 0;
System.Int32 n3 = 0;
//System.int   n4 = 0; // error

double d1 = 0;
Double d2 = 0;
System.Double d3 = 0;

string s1 = "A";
String s2 = "A";
System.String s3 = "A";

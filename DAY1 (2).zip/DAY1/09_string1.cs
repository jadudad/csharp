using System;
using static System.Console;

// mutable, immutable, string

string s1 = "AB";

char c = s1[0]; // ok
s1[0] = 'X';    // error

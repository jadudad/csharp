﻿// entry - 5 page 

class Program
{
    public static void Main()
    {
        System.Console.WriteLine("hello, C#");
    }
}
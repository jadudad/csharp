using static System.Console;

// null-coalescing operator (?? ������)


int?   n1 = null;
string s1 = null;

// 
int n2 = n1;
string s2 = s1;



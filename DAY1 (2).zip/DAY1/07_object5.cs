﻿// 33 page
// static method vs instance method
// instance method : 객체.메소드이름() 으로 호출
//                   객체의 데이타와 관련 된 기능 수행

// static method : 타입.메소드이름() 으로 호출
//                 특정 데이타와는 관련없고, 타입과 연관된 기능수행

int n1 = 10;
var s1 = n1.ToString();

int n2 = int.Parse("20");

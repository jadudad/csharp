using Sys = System;
using Std = System.Console;

Sys.Console.WriteLine("Hello");
Std.WriteLine("Hello");

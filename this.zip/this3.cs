﻿class Point
{
    public int x = 0;
    public int y = 0;    

    public void Set(int a, int b) => (x, y) = (a, b);

    public static void Foo(int a)
    {
        x = a;
        Set(10, 20);
    }
}

class Program
{
    public static void Main()
    {
        // static method 핵심 : 객체없이 호출가능. 클래스 이름으로 호출
        

    }
}
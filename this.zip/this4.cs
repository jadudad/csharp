﻿delegate void MyFunc(int arg);

// delegate 에 메소드를 등록할때
// static   메소드는 "클래스이름.메소드이름" 으로 등록
// instance 메소드는 "객체이름.메소드이름" 으로

class Example
{
    public        void IM(int arg) { }
    public static void SM(int arg) { }

    public void InstanceMethod()
    {
        MyFunc f = ?;
    }
}

class Program
{
    public static void Main()
    {
        Example e = new Example();
        
        e.InstanceMethod();


    }
}
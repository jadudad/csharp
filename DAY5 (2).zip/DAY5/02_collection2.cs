﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// generic vs non-generic

class Program
{
    public static void Main()
    {
        // C# 1.0 Generic 문법이 없었다.
        ArrayList c1 = new ArrayList();



    }
}
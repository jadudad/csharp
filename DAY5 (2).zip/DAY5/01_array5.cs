﻿using static System.Console;

// #1. array method
int[] arr1 = { 1, 2, 3, 4, 5 };
int[,] arr2 = { { 1, 2,3 }, { 3, 4, 5 }};

WriteLine(arr1.Length);
WriteLine(arr2.Length);
WriteLine(arr2.GetLength(0));
WriteLine(arr2.GetLength(1));

/*
// method from object - 4개
arr.GetType();
arr.ToString();
arr.GetHashCode();
arr.Equals();

// method from Array - 10개
arr.GetEnumerator();
arr.SetValue();
arr.GetValue();
arr.Initialize();
arr.Clone();
arr.CopyTo();
arr.GetLength();
arr.GetLongLength();
arr.GetLowerBound();
arr.GetUpperBound();
*/



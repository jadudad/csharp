﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// enumerator

class Program
{
    public static void Main()
    {
        List<int>       c1 = new List<int>();
        LinkedList<int> c2 = new LinkedList<int>();

        for (int i = 0; i < 5; i++)
        {
            c1.Add(i);
            c2.AddLast(i);
        }


    }
}







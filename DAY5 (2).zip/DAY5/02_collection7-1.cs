﻿using System;
using System.Collections;
using System.Collections.Generic;
using static System.Console;

// 주제 6. 사용자 정의 타입과 해쉬, Equals(), GetHashCode()

class People
{
    public string name;
    public int age;

    public People(string n, int a) { name = n; age = a; }
}

class Program
{
    public static void Main()
    {
        HashSet<People> hs = new HashSet<People>();

        People p1 = new People("Kim", 20);
        People p2 = new People("Lee", 30);

        hs.Add(p1);
        hs.Add(p2);

        People p3 = new People("Kim", 20);

        WriteLine(hs.Contains(p3)); // false 특정 사람 검색.
       
    }
}
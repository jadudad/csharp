﻿using static System.Console;

// #3. 배열을 생성하는 방법

int[] arr1 = new int[5] { 1, 2, 3, 4, 5 };
int[] arr2 = new int[5];

int[] arr3 = new[] { 1, 2, 3, 4, 5 };

int[] arr4 = { 1, 2, 3, 4, 5 }; // 일반적인 코드

int[] arr5 = [1, 2, 3, 4, 5];   // C#12.0 이후 사용하는 방식


int[] arr6 = (int[])Array.CreateInstance(typeof(int), 5);

var arr7 = { 1, 2, 3, 4, 5 };
var arr8 = [1, 2, 3, 4, 5];
var arr9 = new[]{ 1, 2, 3, 4, 5 };



﻿using System.Reflection;
using static System.Console;

// Array Static method
int[] arr = { 1, 2, 3, 4, 5 };
//-----------------------
/*
Array.AsReadOnly();
Array.BinarySearch();
Array.Clear();
Array.ConstrainedCopy();
Array.ConvertAll();
Array.Copy();
Array.CreateInstance();
Array.Empty();
Array.Equals();
Array.Exists();
Array.Fill();
Array.Find();
Array.FindAll();
Array.FindIndex();
Array.FindLast();
Array.FindLastIndex();
Array.ForEach();
Array.IndexOf();
Array.LastIndexOf();
Array.ReferenceEquals();
Array.Resize();
Array.Reverse();
Array.Sort();
Array.TrueForAll();
*/

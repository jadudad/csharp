using static System.Console;

// extension method( 115p ~ )

class Example 
{
	public void Foo() => WriteLine("Example Foo");
}

class Program
{
	public static void Main()
	{
		Example e = new();
		e.Foo();
		e.Goo(3); // ?
	}
}

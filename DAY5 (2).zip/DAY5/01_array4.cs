﻿using static System.Console;

// 배열이 가진 속성(property)

int[] arr = { 1, 2, 3, 4, 5 };

WriteLine($"{arr.Length}");
WriteLine($"{arr.LongLength}");
WriteLine($"{arr.Rank}");
WriteLine($"{arr.IsReadOnly}");
WriteLine($"{arr.IsFixedSize}");
WriteLine($"{arr.IsSynchronized}");


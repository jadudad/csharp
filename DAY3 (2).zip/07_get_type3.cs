using System;
using static System.Console;

class Program
{	
	public static void Foo(object obj)
	{
		Type t = obj.GetType();
		WriteLine($"{t.Name}");

		// obj 가 int 인지 확인하고 싶다.

	}

	public static void Main()
	{
		int n = 10;
		string s = "ABC";

		Foo(n);
		Foo(s);
	}
}
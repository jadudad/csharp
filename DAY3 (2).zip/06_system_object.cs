using static System.Console;

// 118 page ~ 

class Car  
{
}

class Program 
{
	public static void Main()
	{
		Car c = new Car();
		
		WriteLine( c.ToString() );
	}
}



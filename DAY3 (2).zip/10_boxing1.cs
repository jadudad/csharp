using static System.Console;

// 137page ~

class CPoint 
{
	public int X{set; get;} = 0;
	public int Y{set; get;}	= 0;
	public CPoint(int a, int b) => (X, Y) = (a, b);
}
class SPoint
{
    public int X { set; get; } = 0;
    public int Y { set; get; } = 0;
    public SPoint(int a, int b) => (X, Y) = (a, b);
}

class Program
{
	public static void Main()
	{
		// �Ʒ� 6�� ����� �޸� ���¸� ������ ���ô�.
		CPoint cp1 = new CPoint(1, 1);
		object co = cp1;
		CPoint cp2 = (CPoint)co;

        SPoint sp1 = new SPoint(1, 1);
        object so = sp1;
        SPoint sp2 = (SPoint)so;
    }
}
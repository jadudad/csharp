using static System.Console;

// 112 page ~ 


class Program 
{
	public static void Main()
	{
		int n1 = 10;
		int n2 = 20;

		string s1 = "AAA";
		string s2 = "BBB";

		// ũ�⸦ ���ϴ� ���. 
	}

}

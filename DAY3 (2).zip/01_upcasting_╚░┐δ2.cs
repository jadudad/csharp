﻿using static System.Console;

class Animal
{
    public int Age { get; set; } = 0;
}
class Dog : Animal
{
    public int Color { get; set; } = 0;
}

class Cat : Animal
{
    public int Speed { get; set; } = 0;
}

class Program
{
    public static void Main()
    {
        Dog[] arr = new Dog[10];

    }
}


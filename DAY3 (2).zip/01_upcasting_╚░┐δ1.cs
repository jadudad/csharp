﻿using static System.Console;

class Animal
{
    public int Age { get; set; } = 0;
}
class Dog : Animal
{
    public int Color { get; set; } = 0;
}

class Cat : Animal
{
    public int Speed { get; set; } = 0;
}

class Program
{
    // 인자로 받은 동물의 나이를 한살 증가하는 메소드
    public static void NewYear(Dog a)
    {
        ++(a.Age);
    }

    public static void Main()
    {
        Dog dog = new Dog();
        Cat cat = new Cat();

        NewYear(dog);
        NewYear(cat); // ?
    }
}



class Program 
{
	public static void M1(){}
	public static void M2(int arg){}
	public static void M3(double arg){}
	public static void M4(int arg1, double arg2){}

	public static void Main()
	{
		? f1 = M1;
		
	}
}

using static System.Console;

interface IMP3 
{
	void Play();
}

class Player : IMP3
{
	public void Play() { WriteLine("Play MP3"); }
}

class Program 
{
	public static void Main()
	{
		Player player = new Player();
		player.Play();

	}
}